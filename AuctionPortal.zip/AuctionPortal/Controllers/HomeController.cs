﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace AuctionPortal.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            DataTable AuctionsTable = new DataTable();

            AuctionsTable = DataController.getAuctions();

            return View(AuctionsTable);
          //  return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
      
    }
}